var Oo=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function nn(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var _t={exports:{}},b={};var xe;function Vn(){if(xe)return b;xe=1;var t=Symbol.for("react.element"),e=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),r=Symbol.for("react.profiler"),o=Symbol.for("react.provider"),i=Symbol.for("react.context"),c=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),u=Symbol.for("react.memo"),d=Symbol.for("react.lazy"),g=Symbol.iterator;function h(s){return s===null||typeof s!="object"?null:(s=g&&s[g]||s["@@iterator"],typeof s=="function"?s:null)}var O={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},z=Object.assign,C={};function x(s,f,v){this.props=s,this.context=f,this.refs=C,this.updater=v||O}x.prototype.isReactComponent={},x.prototype.setState=function(s,f){if(typeof s!="object"&&typeof s!="function"&&s!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,s,f,"setState")},x.prototype.forceUpdate=function(s){this.updater.enqueueForceUpdate(this,s,"forceUpdate")};function A(){}A.prototype=x.prototype;function S(s,f,v){this.props=s,this.context=f,this.refs=C,this.updater=v||O}var L=S.prototype=new A;L.constructor=S,z(L,x.prototype),L.isPureReactComponent=!0;var F=Array.isArray,j=Object.prototype.hasOwnProperty,q={current:null},Y={key:!0,ref:!0,__self:!0,__source:!0};function H(s,f,v){var k,w={},M=null,N=null;if(f!=null)for(k in f.ref!==void 0&&(N=f.ref),f.key!==void 0&&(M=""+f.key),f)j.call(f,k)&&!Y.hasOwnProperty(k)&&(w[k]=f[k]);var _=arguments.length-2;if(_===1)w.children=v;else if(1<_){for(var E=Array(_),D=0;D<_;D++)E[D]=arguments[D+2];w.children=E}if(s&&s.defaultProps)for(k in _=s.defaultProps,_)w[k]===void 0&&(w[k]=_[k]);return{$$typeof:t,type:s,key:M,ref:N,props:w,_owner:q.current}}function Yn(s,f){return{$$typeof:t,type:s.type,key:f,ref:s.ref,props:s.props,_owner:s._owner}}function Et(s){return typeof s=="object"&&s!==null&&s.$$typeof===t}function Hn(s){var f={"=":"=0",":":"=2"};return"$"+s.replace(/[=:]/g,function(v){return f[v]})}var be=/\/+/g;function Mt(s,f){return typeof s=="object"&&s!==null&&s.key!=null?Hn(""+s.key):f.toString(36)}function pt(s,f,v,k,w){var M=typeof s;(M==="undefined"||M==="boolean")&&(s=null);var N=!1;if(s===null)N=!0;else switch(M){case"string":case"number":N=!0;break;case"object":switch(s.$$typeof){case t:case e:N=!0}}if(N)return N=s,w=w(N),s=k===""?"."+Mt(N,0):k,F(w)?(v="",s!=null&&(v=s.replace(be,"$&/")+"/"),pt(w,f,v,"",function(D){return D})):w!=null&&(Et(w)&&(w=Yn(w,v+(!w.key||N&&N.key===w.key?"":(""+w.key).replace(be,"$&/")+"/")+s)),f.push(w)),1;if(N=0,k=k===""?".":k+":",F(s))for(var _=0;_<s.length;_++){M=s[_];var E=k+Mt(M,_);N+=pt(M,f,v,E,w)}else if(E=h(s),typeof E=="function")for(s=E.call(s),_=0;!(M=s.next()).done;)M=M.value,E=k+Mt(M,_++),N+=pt(M,f,v,E,w);else if(M==="object")throw f=String(s),Error("Objects are not valid as a React child (found: "+(f==="[object Object]"?"object with keys {"+Object.keys(s).join(", ")+"}":f)+"). If you meant to render a collection of children, use an array instead.");return N}function ht(s,f,v){if(s==null)return s;var k=[],w=0;return pt(s,k,"","",function(M){return f.call(v,M,w++)}),k}function Bn(s){if(s._status===-1){var f=s._result;f=f(),f.then(function(v){(s._status===0||s._status===-1)&&(s._status=1,s._result=v)},function(v){(s._status===0||s._status===-1)&&(s._status=2,s._result=v)}),s._status===-1&&(s._status=0,s._result=f)}if(s._status===1)return s._result.default;throw s._result}var T={current:null},gt={transition:null},Gn={ReactCurrentDispatcher:T,ReactCurrentBatchConfig:gt,ReactCurrentOwner:q};function ve(){throw Error("act(...) is not supported in production builds of React.")}return b.Children={map:ht,forEach:function(s,f,v){ht(s,function(){f.apply(this,arguments)},v)},count:function(s){var f=0;return ht(s,function(){f++}),f},toArray:function(s){return ht(s,function(f){return f})||[]},only:function(s){if(!Et(s))throw Error("React.Children.only expected to receive a single React element child.");return s}},b.Component=x,b.Fragment=n,b.Profiler=r,b.PureComponent=S,b.StrictMode=a,b.Suspense=m,b.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Gn,b.act=ve,b.cloneElement=function(s,f,v){if(s==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+s+".");var k=z({},s.props),w=s.key,M=s.ref,N=s._owner;if(f!=null){if(f.ref!==void 0&&(M=f.ref,N=q.current),f.key!==void 0&&(w=""+f.key),s.type&&s.type.defaultProps)var _=s.type.defaultProps;for(E in f)j.call(f,E)&&!Y.hasOwnProperty(E)&&(k[E]=f[E]===void 0&&_!==void 0?_[E]:f[E])}var E=arguments.length-2;if(E===1)k.children=v;else if(1<E){_=Array(E);for(var D=0;D<E;D++)_[D]=arguments[D+2];k.children=_}return{$$typeof:t,type:s.type,key:w,ref:M,props:k,_owner:N}},b.createContext=function(s){return s={$$typeof:i,_currentValue:s,_currentValue2:s,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},s.Provider={$$typeof:o,_context:s},s.Consumer=s},b.createElement=H,b.createFactory=function(s){var f=H.bind(null,s);return f.type=s,f},b.createRef=function(){return{current:null}},b.forwardRef=function(s){return{$$typeof:c,render:s}},b.isValidElement=Et,b.lazy=function(s){return{$$typeof:d,_payload:{_status:-1,_result:s},_init:Bn}},b.memo=function(s,f){return{$$typeof:u,type:s,compare:f===void 0?null:f}},b.startTransition=function(s){var f=gt.transition;gt.transition={};try{s()}finally{gt.transition=f}},b.unstable_act=ve,b.useCallback=function(s,f){return T.current.useCallback(s,f)},b.useContext=function(s){return T.current.useContext(s)},b.useDebugValue=function(){},b.useDeferredValue=function(s){return T.current.useDeferredValue(s)},b.useEffect=function(s,f){return T.current.useEffect(s,f)},b.useId=function(){return T.current.useId()},b.useImperativeHandle=function(s,f,v){return T.current.useImperativeHandle(s,f,v)},b.useInsertionEffect=function(s,f){return T.current.useInsertionEffect(s,f)},b.useLayoutEffect=function(s,f){return T.current.useLayoutEffect(s,f)},b.useMemo=function(s,f){return T.current.useMemo(s,f)},b.useReducer=function(s,f,v){return T.current.useReducer(s,f,v)},b.useRef=function(s){return T.current.useRef(s)},b.useState=function(s){return T.current.useState(s)},b.useSyncExternalStore=function(s,f,v){return T.current.useSyncExternalStore(s,f,v)},b.useTransition=function(){return T.current.useTransition()},b.version="18.3.1",b}var Ae;function qn(){return Ae||(Ae=1,_t.exports=Vn()),_t.exports}var Xn=qn();const an=nn(Xn);function Kn(t,e,n){return(e=Jn(e))in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function we(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(t);e&&(a=a.filter(function(r){return Object.getOwnPropertyDescriptor(t,r).enumerable})),n.push.apply(n,a)}return n}function l(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]!=null?arguments[e]:{};e%2?we(Object(n),!0).forEach(function(a){Kn(t,a,n[a])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):we(Object(n)).forEach(function(a){Object.defineProperty(t,a,Object.getOwnPropertyDescriptor(n,a))})}return t}function Qn(t,e){if(typeof t!="object"||!t)return t;var n=t[Symbol.toPrimitive];if(n!==void 0){var a=n.call(t,e);if(typeof a!="object")return a;throw new TypeError("@@toPrimitive must return a primitive value.")}return(e==="string"?String:Number)(t)}function Jn(t){var e=Qn(t,"string");return typeof e=="symbol"?e:e+""}const Se=()=>{};let ie={},rn={},on=null,sn={mark:Se,measure:Se};try{typeof window<"u"&&(ie=window),typeof document<"u"&&(rn=document),typeof MutationObserver<"u"&&(on=MutationObserver),typeof performance<"u"&&(sn=performance)}catch{}const{userAgent:ke=""}=ie.navigator||{},Q=ie,P=rn,Pe=on,yt=sn;Q.document;const V=!!P.documentElement&&!!P.head&&typeof P.addEventListener=="function"&&typeof P.createElement=="function",cn=~ke.indexOf("MSIE")||~ke.indexOf("Trident/");var Zn=/fa(s|r|l|t|d|dr|dl|dt|b|k|kd|ss|sr|sl|st|sds|sdr|sdl|sdt)?[\-\ ]/,ta=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit)?.*/i,ln={classic:{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fab:"brands","fa-brands":"brands"},duotone:{fa:"solid",fad:"solid","fa-solid":"solid","fa-duotone":"solid",fadr:"regular","fa-regular":"regular",fadl:"light","fa-light":"light",fadt:"thin","fa-thin":"thin"},sharp:{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light",fast:"thin","fa-thin":"thin"},"sharp-duotone":{fa:"solid",fasds:"solid","fa-solid":"solid",fasdr:"regular","fa-regular":"regular",fasdl:"light","fa-light":"light",fasdt:"thin","fa-thin":"thin"}},ea={GROUP:"duotone-group",PRIMARY:"primary",SECONDARY:"secondary"},fn=["fa-classic","fa-duotone","fa-sharp","fa-sharp-duotone"],I="classic",kt="duotone",na="sharp",aa="sharp-duotone",un=[I,kt,na,aa],ra={classic:{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"},duotone:{900:"fad",400:"fadr",300:"fadl",100:"fadt"},sharp:{900:"fass",400:"fasr",300:"fasl",100:"fast"},"sharp-duotone":{900:"fasds",400:"fasdr",300:"fasdl",100:"fasdt"}},oa={"Font Awesome 6 Free":{900:"fas",400:"far"},"Font Awesome 6 Pro":{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"},"Font Awesome 6 Brands":{400:"fab",normal:"fab"},"Font Awesome 6 Duotone":{900:"fad",400:"fadr",normal:"fadr",300:"fadl",100:"fadt"},"Font Awesome 6 Sharp":{900:"fass",400:"fasr",normal:"fasr",300:"fasl",100:"fast"},"Font Awesome 6 Sharp Duotone":{900:"fasds",400:"fasdr",normal:"fasdr",300:"fasdl",100:"fasdt"}},sa=new Map([["classic",{defaultShortPrefixId:"fas",defaultStyleId:"solid",styleIds:["solid","regular","light","thin","brands"],futureStyleIds:[],defaultFontWeight:900}],["sharp",{defaultShortPrefixId:"fass",defaultStyleId:"solid",styleIds:["solid","regular","light","thin"],futureStyleIds:[],defaultFontWeight:900}],["duotone",{defaultShortPrefixId:"fad",defaultStyleId:"solid",styleIds:["solid","regular","light","thin"],futureStyleIds:[],defaultFontWeight:900}],["sharp-duotone",{defaultShortPrefixId:"fasds",defaultStyleId:"solid",styleIds:["solid","regular","light","thin"],futureStyleIds:[],defaultFontWeight:900}]]),ia={classic:{solid:"fas",regular:"far",light:"fal",thin:"fat",brands:"fab"},duotone:{solid:"fad",regular:"fadr",light:"fadl",thin:"fadt"},sharp:{solid:"fass",regular:"fasr",light:"fasl",thin:"fast"},"sharp-duotone":{solid:"fasds",regular:"fasdr",light:"fasdl",thin:"fasdt"}},ca=["fak","fa-kit","fakd","fa-kit-duotone"],Oe={kit:{fak:"kit","fa-kit":"kit"},"kit-duotone":{fakd:"kit-duotone","fa-kit-duotone":"kit-duotone"}},la=["kit"],fa={kit:{"fa-kit":"fak"}},ua=["fak","fakd"],ma={kit:{fak:"fa-kit"}},Ce={kit:{kit:"fak"},"kit-duotone":{"kit-duotone":"fakd"}},bt={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},da=["fa-classic","fa-duotone","fa-sharp","fa-sharp-duotone"],pa=["fak","fa-kit","fakd","fa-kit-duotone"],ha={"Font Awesome Kit":{400:"fak",normal:"fak"},"Font Awesome Kit Duotone":{400:"fakd",normal:"fakd"}},ga={classic:{"fa-brands":"fab","fa-duotone":"fad","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"},duotone:{"fa-regular":"fadr","fa-light":"fadl","fa-thin":"fadt"},sharp:{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl","fa-thin":"fast"},"sharp-duotone":{"fa-solid":"fasds","fa-regular":"fasdr","fa-light":"fasdl","fa-thin":"fasdt"}},ya={classic:["fas","far","fal","fat","fad"],duotone:["fadr","fadl","fadt"],sharp:["fass","fasr","fasl","fast"],"sharp-duotone":["fasds","fasdr","fasdl","fasdt"]},Wt={classic:{fab:"fa-brands",fad:"fa-duotone",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"},duotone:{fadr:"fa-regular",fadl:"fa-light",fadt:"fa-thin"},sharp:{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light",fast:"fa-thin"},"sharp-duotone":{fasds:"fa-solid",fasdr:"fa-regular",fasdl:"fa-light",fasdt:"fa-thin"}},ba=["fa-solid","fa-regular","fa-light","fa-thin","fa-duotone","fa-brands"],$t=["fa","fas","far","fal","fat","fad","fadr","fadl","fadt","fab","fass","fasr","fasl","fast","fasds","fasdr","fasdl","fasdt",...da,...ba],va=["solid","regular","light","thin","duotone","brands"],mn=[1,2,3,4,5,6,7,8,9,10],xa=mn.concat([11,12,13,14,15,16,17,18,19,20]),Aa=[...Object.keys(ya),...va,"2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","fw","inverse","layers-counter","layers-text","layers","li","pull-left","pull-right","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul",bt.GROUP,bt.SWAP_OPACITY,bt.PRIMARY,bt.SECONDARY].concat(mn.map(t=>"".concat(t,"x"))).concat(xa.map(t=>"w-".concat(t))),wa={"Font Awesome 5 Free":{900:"fas",400:"far"},"Font Awesome 5 Pro":{900:"fas",400:"far",normal:"far",300:"fal"},"Font Awesome 5 Brands":{400:"fab",normal:"fab"},"Font Awesome 5 Duotone":{900:"fad"}};const B="___FONT_AWESOME___",Yt=16,dn="fa",pn="svg-inline--fa",et="data-fa-i2svg",Ht="data-fa-pseudo-element",Sa="data-fa-pseudo-element-pending",ce="data-prefix",le="data-icon",Le="fontawesome-i2svg",ka="async",Pa=["HTML","HEAD","STYLE","SCRIPT"],hn=(()=>{try{return!0}catch{return!1}})();function mt(t){return new Proxy(t,{get(e,n){return n in e?e[n]:e[I]}})}const gn=l({},ln);gn[I]=l(l(l(l({},{"fa-duotone":"duotone"}),ln[I]),Oe.kit),Oe["kit-duotone"]);const Oa=mt(gn),Bt=l({},ia);Bt[I]=l(l(l(l({},{duotone:"fad"}),Bt[I]),Ce.kit),Ce["kit-duotone"]);const Ee=mt(Bt),Gt=l({},Wt);Gt[I]=l(l({},Gt[I]),ma.kit);const fe=mt(Gt),Vt=l({},ga);Vt[I]=l(l({},Vt[I]),fa.kit);mt(Vt);const Ca=Zn,yn="fa-layers-text",La=ta,Ea=l({},ra);mt(Ea);const Ma=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],Nt=ea,_a=[...la,...Aa],ct=Q.FontAwesomeConfig||{};function Na(t){var e=P.querySelector("script["+t+"]");if(e)return e.getAttribute(t)}function za(t){return t===""?!0:t==="false"?!1:t==="true"?!0:t}P&&typeof P.querySelector=="function"&&[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-auto-a11y","autoA11y"],["data-search-pseudo-elements","searchPseudoElements"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]].forEach(e=>{let[n,a]=e;const r=za(Na(n));r!=null&&(ct[a]=r)});const bn={styleDefault:"solid",familyDefault:I,cssPrefix:dn,replacementClass:pn,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};ct.familyPrefix&&(ct.cssPrefix=ct.familyPrefix);const ot=l(l({},bn),ct);ot.autoReplaceSvg||(ot.observeMutations=!1);const p={};Object.keys(bn).forEach(t=>{Object.defineProperty(p,t,{enumerable:!0,set:function(e){ot[t]=e,lt.forEach(n=>n(p))},get:function(){return ot[t]}})});Object.defineProperty(p,"familyPrefix",{enumerable:!0,set:function(t){ot.cssPrefix=t,lt.forEach(e=>e(p))},get:function(){return ot.cssPrefix}});Q.FontAwesomeConfig=p;const lt=[];function Ia(t){return lt.push(t),()=>{lt.splice(lt.indexOf(t),1)}}const X=Yt,W={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function Ta(t){if(!t||!V)return;const e=P.createElement("style");e.setAttribute("type","text/css"),e.innerHTML=t;const n=P.head.childNodes;let a=null;for(let r=n.length-1;r>-1;r--){const o=n[r],i=(o.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(i)>-1&&(a=o)}return P.head.insertBefore(e,a),t}const Ra="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function ft(){let t=12,e="";for(;t-- >0;)e+=Ra[Math.random()*62|0];return e}function st(t){const e=[];for(let n=(t||[]).length>>>0;n--;)e[n]=t[n];return e}function ue(t){return t.classList?st(t.classList):(t.getAttribute("class")||"").split(" ").filter(e=>e)}function vn(t){return"".concat(t).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Fa(t){return Object.keys(t||{}).reduce((e,n)=>e+"".concat(n,'="').concat(vn(t[n]),'" '),"").trim()}function Pt(t){return Object.keys(t||{}).reduce((e,n)=>e+"".concat(n,": ").concat(t[n].trim(),";"),"")}function me(t){return t.size!==W.size||t.x!==W.x||t.y!==W.y||t.rotate!==W.rotate||t.flipX||t.flipY}function ja(t){let{transform:e,containerWidth:n,iconWidth:a}=t;const r={transform:"translate(".concat(n/2," 256)")},o="translate(".concat(e.x*32,", ").concat(e.y*32,") "),i="scale(".concat(e.size/16*(e.flipX?-1:1),", ").concat(e.size/16*(e.flipY?-1:1),") "),c="rotate(".concat(e.rotate," 0 0)"),m={transform:"".concat(o," ").concat(i," ").concat(c)},u={transform:"translate(".concat(a/2*-1," -256)")};return{outer:r,inner:m,path:u}}function Da(t){let{transform:e,width:n=Yt,height:a=Yt,startCentered:r=!1}=t,o="";return r&&cn?o+="translate(".concat(e.x/X-n/2,"em, ").concat(e.y/X-a/2,"em) "):r?o+="translate(calc(-50% + ".concat(e.x/X,"em), calc(-50% + ").concat(e.y/X,"em)) "):o+="translate(".concat(e.x/X,"em, ").concat(e.y/X,"em) "),o+="scale(".concat(e.size/X*(e.flipX?-1:1),", ").concat(e.size/X*(e.flipY?-1:1),") "),o+="rotate(".concat(e.rotate,"deg) "),o}var Ua=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Free";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Free";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Pro";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Pro";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-duotone-regular: normal 400 1em/1 "Font Awesome 6 Duotone";
  --fa-font-duotone-light: normal 300 1em/1 "Font Awesome 6 Duotone";
  --fa-font-duotone-thin: normal 100 1em/1 "Font Awesome 6 Duotone";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-duotone-solid: normal 900 1em/1 "Font Awesome 6 Sharp Duotone";
  --fa-font-sharp-duotone-regular: normal 400 1em/1 "Font Awesome 6 Sharp Duotone";
  --fa-font-sharp-duotone-light: normal 300 1em/1 "Font Awesome 6 Sharp Duotone";
  --fa-font-sharp-duotone-thin: normal 100 1em/1 "Font Awesome 6 Sharp Duotone";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-counter-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(-1 * var(--fa-li-width, 2em));
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  animation-name: fa-beat;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  animation-name: fa-bounce;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  animation-name: fa-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  animation-name: fa-beat-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  animation-name: fa-flip;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  animation-name: fa-shake;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  animation-name: fa-spin;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 2s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  animation-name: fa-spin;
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    animation-delay: -1ms;
    animation-duration: 1ms;
    animation-iteration-count: 1;
    transition-delay: 0s;
    transition-duration: 0s;
  }
}
@keyframes fa-beat {
  0%, 90% {
    transform: scale(1);
  }
  45% {
    transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-bounce {
  0% {
    transform: scale(1, 1) translateY(0);
  }
  10% {
    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    transform: scale(1, 1) translateY(0);
  }
  100% {
    transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-flip {
  50% {
    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-shake {
  0% {
    transform: rotate(-15deg);
  }
  4% {
    transform: rotate(15deg);
  }
  8%, 24% {
    transform: rotate(-18deg);
  }
  12%, 28% {
    transform: rotate(18deg);
  }
  16% {
    transform: rotate(-22deg);
  }
  20% {
    transform: rotate(22deg);
  }
  32% {
    transform: rotate(-12deg);
  }
  36% {
    transform: rotate(12deg);
  }
  40%, 100% {
    transform: rotate(0deg);
  }
}
@keyframes fa-spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  transform: rotate(90deg);
}

.fa-rotate-180 {
  transform: rotate(180deg);
}

.fa-rotate-270 {
  transform: rotate(270deg);
}

.fa-flip-horizontal {
  transform: scale(-1, 1);
}

.fa-flip-vertical {
  transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  transform: scale(-1, -1);
}

.fa-rotate-by {
  transform: rotate(var(--fa-rotate-angle, 0));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}`;function xn(){const t=dn,e=pn,n=p.cssPrefix,a=p.replacementClass;let r=Ua;if(n!==t||a!==e){const o=new RegExp("\\.".concat(t,"\\-"),"g"),i=new RegExp("\\--".concat(t,"\\-"),"g"),c=new RegExp("\\.".concat(e),"g");r=r.replace(o,".".concat(n,"-")).replace(i,"--".concat(n,"-")).replace(c,".".concat(a))}return r}let Me=!1;function zt(){p.autoAddCss&&!Me&&(Ta(xn()),Me=!0)}var Wa={mixout(){return{dom:{css:xn,insertCss:zt}}},hooks(){return{beforeDOMElementCreation(){zt()},beforeI2svg(){zt()}}}};const G=Q||{};G[B]||(G[B]={});G[B].styles||(G[B].styles={});G[B].hooks||(G[B].hooks={});G[B].shims||(G[B].shims=[]);var $=G[B];const An=[],wn=function(){P.removeEventListener("DOMContentLoaded",wn),At=1,An.map(t=>t())};let At=!1;V&&(At=(P.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(P.readyState),At||P.addEventListener("DOMContentLoaded",wn));function $a(t){V&&(At?setTimeout(t,0):An.push(t))}function dt(t){const{tag:e,attributes:n={},children:a=[]}=t;return typeof t=="string"?vn(t):"<".concat(e," ").concat(Fa(n),">").concat(a.map(dt).join(""),"</").concat(e,">")}function _e(t,e,n){if(t&&t[e]&&t[e][n])return{prefix:e,iconName:n,icon:t[e][n]}}var It=function(e,n,a,r){var o=Object.keys(e),i=o.length,c=n,m,u,d;for(a===void 0?(m=1,d=e[o[0]]):(m=0,d=a);m<i;m++)u=o[m],d=c(d,e[u],u,e);return d};function Ya(t){const e=[];let n=0;const a=t.length;for(;n<a;){const r=t.charCodeAt(n++);if(r>=55296&&r<=56319&&n<a){const o=t.charCodeAt(n++);(o&64512)==56320?e.push(((r&1023)<<10)+(o&1023)+65536):(e.push(r),n--)}else e.push(r)}return e}function qt(t){const e=Ya(t);return e.length===1?e[0].toString(16):null}function Ha(t,e){const n=t.length;let a=t.charCodeAt(e),r;return a>=55296&&a<=56319&&n>e+1&&(r=t.charCodeAt(e+1),r>=56320&&r<=57343)?(a-55296)*1024+r-56320+65536:a}function Ne(t){return Object.keys(t).reduce((e,n)=>{const a=t[n];return!!a.icon?e[a.iconName]=a.icon:e[n]=a,e},{})}function Xt(t,e){let n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};const{skipHooks:a=!1}=n,r=Ne(e);typeof $.hooks.addPack=="function"&&!a?$.hooks.addPack(t,Ne(e)):$.styles[t]=l(l({},$.styles[t]||{}),r),t==="fas"&&Xt("fa",e)}const{styles:ut,shims:Ba}=$,Sn=Object.keys(fe),Ga=Sn.reduce((t,e)=>(t[e]=Object.keys(fe[e]),t),{});let de=null,kn={},Pn={},On={},Cn={},Ln={};function Va(t){return~_a.indexOf(t)}function qa(t,e){const n=e.split("-"),a=n[0],r=n.slice(1).join("-");return a===t&&r!==""&&!Va(r)?r:null}const En=()=>{const t=a=>It(ut,(r,o,i)=>(r[i]=It(o,a,{}),r),{});kn=t((a,r,o)=>(r[3]&&(a[r[3]]=o),r[2]&&r[2].filter(c=>typeof c=="number").forEach(c=>{a[c.toString(16)]=o}),a)),Pn=t((a,r,o)=>(a[o]=o,r[2]&&r[2].filter(c=>typeof c=="string").forEach(c=>{a[c]=o}),a)),Ln=t((a,r,o)=>{const i=r[2];return a[o]=o,i.forEach(c=>{a[c]=o}),a});const e="far"in ut||p.autoFetchSvg,n=It(Ba,(a,r)=>{const o=r[0];let i=r[1];const c=r[2];return i==="far"&&!e&&(i="fas"),typeof o=="string"&&(a.names[o]={prefix:i,iconName:c}),typeof o=="number"&&(a.unicodes[o.toString(16)]={prefix:i,iconName:c}),a},{names:{},unicodes:{}});On=n.names,Cn=n.unicodes,de=Ot(p.styleDefault,{family:p.familyDefault})};Ia(t=>{de=Ot(t.styleDefault,{family:p.familyDefault})});En();function pe(t,e){return(kn[t]||{})[e]}function Xa(t,e){return(Pn[t]||{})[e]}function tt(t,e){return(Ln[t]||{})[e]}function Mn(t){return On[t]||{prefix:null,iconName:null}}function Ka(t){const e=Cn[t],n=pe("fas",t);return e||(n?{prefix:"fas",iconName:n}:null)||{prefix:null,iconName:null}}function J(){return de}const _n=()=>({prefix:null,iconName:null,rest:[]});function Qa(t){let e=I;const n=Sn.reduce((a,r)=>(a[r]="".concat(p.cssPrefix,"-").concat(r),a),{});return un.forEach(a=>{(t.includes(n[a])||t.some(r=>Ga[a].includes(r)))&&(e=a)}),e}function Ot(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{family:n=I}=e,a=Oa[n][t];if(n===kt&&!t)return"fad";const r=Ee[n][t]||Ee[n][a],o=t in $.styles?t:null;return r||o||null}function Ja(t){let e=[],n=null;return t.forEach(a=>{const r=qa(p.cssPrefix,a);r?n=r:a&&e.push(a)}),{iconName:n,rest:e}}function ze(t){return t.sort().filter((e,n,a)=>a.indexOf(e)===n)}function Ct(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{skipLookups:n=!1}=e;let a=null;const r=$t.concat(pa),o=ze(t.filter(g=>r.includes(g))),i=ze(t.filter(g=>!$t.includes(g))),c=o.filter(g=>(a=g,!fn.includes(g))),[m=null]=c,u=Qa(o),d=l(l({},Ja(i)),{},{prefix:Ot(m,{family:u})});return l(l(l({},d),nr({values:t,family:u,styles:ut,config:p,canonical:d,givenPrefix:a})),Za(n,a,d))}function Za(t,e,n){let{prefix:a,iconName:r}=n;if(t||!a||!r)return{prefix:a,iconName:r};const o=e==="fa"?Mn(r):{},i=tt(a,r);return r=o.iconName||i||r,a=o.prefix||a,a==="far"&&!ut.far&&ut.fas&&!p.autoFetchSvg&&(a="fas"),{prefix:a,iconName:r}}const tr=un.filter(t=>t!==I||t!==kt),er=Object.keys(Wt).filter(t=>t!==I).map(t=>Object.keys(Wt[t])).flat();function nr(t){const{values:e,family:n,canonical:a,givenPrefix:r="",styles:o={},config:i={}}=t,c=n===kt,m=e.includes("fa-duotone")||e.includes("fad"),u=i.familyDefault==="duotone",d=a.prefix==="fad"||a.prefix==="fa-duotone";if(!c&&(m||u||d)&&(a.prefix="fad"),(e.includes("fa-brands")||e.includes("fab"))&&(a.prefix="fab"),!a.prefix&&tr.includes(n)&&(Object.keys(o).find(h=>er.includes(h))||i.autoFetchSvg)){const h=sa.get(n).defaultShortPrefixId;a.prefix=h,a.iconName=tt(a.prefix,a.iconName)||a.iconName}return(a.prefix==="fa"||r==="fa")&&(a.prefix=J()||"fas"),a}class ar{constructor(){this.definitions={}}add(){for(var e=arguments.length,n=new Array(e),a=0;a<e;a++)n[a]=arguments[a];const r=n.reduce(this._pullDefinitions,{});Object.keys(r).forEach(o=>{this.definitions[o]=l(l({},this.definitions[o]||{}),r[o]),Xt(o,r[o]);const i=fe[I][o];i&&Xt(i,r[o]),En()})}reset(){this.definitions={}}_pullDefinitions(e,n){const a=n.prefix&&n.iconName&&n.icon?{0:n}:n;return Object.keys(a).map(r=>{const{prefix:o,iconName:i,icon:c}=a[r],m=c[2];e[o]||(e[o]={}),m.length>0&&m.forEach(u=>{typeof u=="string"&&(e[o][u]=c)}),e[o][i]=c}),e}}let Ie=[],at={};const rt={},rr=Object.keys(rt);function or(t,e){let{mixoutsTo:n}=e;return Ie=t,at={},Object.keys(rt).forEach(a=>{rr.indexOf(a)===-1&&delete rt[a]}),Ie.forEach(a=>{const r=a.mixout?a.mixout():{};if(Object.keys(r).forEach(o=>{typeof r[o]=="function"&&(n[o]=r[o]),typeof r[o]=="object"&&Object.keys(r[o]).forEach(i=>{n[o]||(n[o]={}),n[o][i]=r[o][i]})}),a.hooks){const o=a.hooks();Object.keys(o).forEach(i=>{at[i]||(at[i]=[]),at[i].push(o[i])})}a.provides&&a.provides(rt)}),n}function Kt(t,e){for(var n=arguments.length,a=new Array(n>2?n-2:0),r=2;r<n;r++)a[r-2]=arguments[r];return(at[t]||[]).forEach(i=>{e=i.apply(null,[e,...a])}),e}function nt(t){for(var e=arguments.length,n=new Array(e>1?e-1:0),a=1;a<e;a++)n[a-1]=arguments[a];(at[t]||[]).forEach(o=>{o.apply(null,n)})}function Z(){const t=arguments[0],e=Array.prototype.slice.call(arguments,1);return rt[t]?rt[t].apply(null,e):void 0}function Qt(t){t.prefix==="fa"&&(t.prefix="fas");let{iconName:e}=t;const n=t.prefix||J();if(e)return e=tt(n,e)||e,_e(Nn.definitions,n,e)||_e($.styles,n,e)}const Nn=new ar,sr=()=>{p.autoReplaceSvg=!1,p.observeMutations=!1,nt("noAuto")},ir={i2svg:function(){let t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return V?(nt("beforeI2svg",t),Z("pseudoElements2svg",t),Z("i2svg",t)):Promise.reject(new Error("Operation requires a DOM of some kind."))},watch:function(){let t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};const{autoReplaceSvgRoot:e}=t;p.autoReplaceSvg===!1&&(p.autoReplaceSvg=!0),p.observeMutations=!0,$a(()=>{lr({autoReplaceSvgRoot:e}),nt("watch",t)})}},cr={icon:t=>{if(t===null)return null;if(typeof t=="object"&&t.prefix&&t.iconName)return{prefix:t.prefix,iconName:tt(t.prefix,t.iconName)||t.iconName};if(Array.isArray(t)&&t.length===2){const e=t[1].indexOf("fa-")===0?t[1].slice(3):t[1],n=Ot(t[0]);return{prefix:n,iconName:tt(n,e)||e}}if(typeof t=="string"&&(t.indexOf("".concat(p.cssPrefix,"-"))>-1||t.match(Ca))){const e=Ct(t.split(" "),{skipLookups:!0});return{prefix:e.prefix||J(),iconName:tt(e.prefix,e.iconName)||e.iconName}}if(typeof t=="string"){const e=J();return{prefix:e,iconName:tt(e,t)||t}}}},R={noAuto:sr,config:p,dom:ir,parse:cr,library:Nn,findIconDefinition:Qt,toHtml:dt},lr=function(){let t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};const{autoReplaceSvgRoot:e=P}=t;(Object.keys($.styles).length>0||p.autoFetchSvg)&&V&&p.autoReplaceSvg&&R.dom.i2svg({node:e})};function Lt(t,e){return Object.defineProperty(t,"abstract",{get:e}),Object.defineProperty(t,"html",{get:function(){return t.abstract.map(n=>dt(n))}}),Object.defineProperty(t,"node",{get:function(){if(!V)return;const n=P.createElement("div");return n.innerHTML=t.html,n.children}}),t}function fr(t){let{children:e,main:n,mask:a,attributes:r,styles:o,transform:i}=t;if(me(i)&&n.found&&!a.found){const{width:c,height:m}=n,u={x:c/m/2,y:.5};r.style=Pt(l(l({},o),{},{"transform-origin":"".concat(u.x+i.x/16,"em ").concat(u.y+i.y/16,"em")}))}return[{tag:"svg",attributes:r,children:e}]}function ur(t){let{prefix:e,iconName:n,children:a,attributes:r,symbol:o}=t;const i=o===!0?"".concat(e,"-").concat(p.cssPrefix,"-").concat(n):o;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:l(l({},r),{},{id:i}),children:a}]}]}function he(t){const{icons:{main:e,mask:n},prefix:a,iconName:r,transform:o,symbol:i,title:c,maskId:m,titleId:u,extra:d,watchable:g=!1}=t,{width:h,height:O}=n.found?n:e,z=ua.includes(a),C=[p.replacementClass,r?"".concat(p.cssPrefix,"-").concat(r):""].filter(j=>d.classes.indexOf(j)===-1).filter(j=>j!==""||!!j).concat(d.classes).join(" ");let x={children:[],attributes:l(l({},d.attributes),{},{"data-prefix":a,"data-icon":r,class:C,role:d.attributes.role||"img",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 ".concat(h," ").concat(O)})};const A=z&&!~d.classes.indexOf("fa-fw")?{width:"".concat(h/O*16*.0625,"em")}:{};g&&(x.attributes[et]=""),c&&(x.children.push({tag:"title",attributes:{id:x.attributes["aria-labelledby"]||"title-".concat(u||ft())},children:[c]}),delete x.attributes.title);const S=l(l({},x),{},{prefix:a,iconName:r,main:e,mask:n,maskId:m,transform:o,symbol:i,styles:l(l({},A),d.styles)}),{children:L,attributes:F}=n.found&&e.found?Z("generateAbstractMask",S)||{children:[],attributes:{}}:Z("generateAbstractIcon",S)||{children:[],attributes:{}};return S.children=L,S.attributes=F,i?ur(S):fr(S)}function Te(t){const{content:e,width:n,height:a,transform:r,title:o,extra:i,watchable:c=!1}=t,m=l(l(l({},i.attributes),o?{title:o}:{}),{},{class:i.classes.join(" ")});c&&(m[et]="");const u=l({},i.styles);me(r)&&(u.transform=Da({transform:r,startCentered:!0,width:n,height:a}),u["-webkit-transform"]=u.transform);const d=Pt(u);d.length>0&&(m.style=d);const g=[];return g.push({tag:"span",attributes:m,children:[e]}),o&&g.push({tag:"span",attributes:{class:"sr-only"},children:[o]}),g}function mr(t){const{content:e,title:n,extra:a}=t,r=l(l(l({},a.attributes),n?{title:n}:{}),{},{class:a.classes.join(" ")}),o=Pt(a.styles);o.length>0&&(r.style=o);const i=[];return i.push({tag:"span",attributes:r,children:[e]}),n&&i.push({tag:"span",attributes:{class:"sr-only"},children:[n]}),i}const{styles:Tt}=$;function Jt(t){const e=t[0],n=t[1],[a]=t.slice(4);let r=null;return Array.isArray(a)?r={tag:"g",attributes:{class:"".concat(p.cssPrefix,"-").concat(Nt.GROUP)},children:[{tag:"path",attributes:{class:"".concat(p.cssPrefix,"-").concat(Nt.SECONDARY),fill:"currentColor",d:a[0]}},{tag:"path",attributes:{class:"".concat(p.cssPrefix,"-").concat(Nt.PRIMARY),fill:"currentColor",d:a[1]}}]}:r={tag:"path",attributes:{fill:"currentColor",d:a}},{found:!0,width:e,height:n,icon:r}}const dr={found:!1,width:512,height:512};function pr(t,e){!hn&&!p.showMissingIcons&&t&&console.error('Icon with name "'.concat(t,'" and prefix "').concat(e,'" is missing.'))}function Zt(t,e){let n=e;return e==="fa"&&p.styleDefault!==null&&(e=J()),new Promise((a,r)=>{if(n==="fa"){const o=Mn(t)||{};t=o.iconName||t,e=o.prefix||e}if(t&&e&&Tt[e]&&Tt[e][t]){const o=Tt[e][t];return a(Jt(o))}pr(t,e),a(l(l({},dr),{},{icon:p.showMissingIcons&&t?Z("missingIconAbstract")||{}:{}}))})}const Re=()=>{},te=p.measurePerformance&&yt&&yt.mark&&yt.measure?yt:{mark:Re,measure:Re},it='FA "6.7.2"',hr=t=>(te.mark("".concat(it," ").concat(t," begins")),()=>zn(t)),zn=t=>{te.mark("".concat(it," ").concat(t," ends")),te.measure("".concat(it," ").concat(t),"".concat(it," ").concat(t," begins"),"".concat(it," ").concat(t," ends"))};var ge={begin:hr,end:zn};const vt=()=>{};function Fe(t){return typeof(t.getAttribute?t.getAttribute(et):null)=="string"}function gr(t){const e=t.getAttribute?t.getAttribute(ce):null,n=t.getAttribute?t.getAttribute(le):null;return e&&n}function yr(t){return t&&t.classList&&t.classList.contains&&t.classList.contains(p.replacementClass)}function br(){return p.autoReplaceSvg===!0?xt.replace:xt[p.autoReplaceSvg]||xt.replace}function vr(t){return P.createElementNS("http://www.w3.org/2000/svg",t)}function xr(t){return P.createElement(t)}function In(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{ceFn:n=t.tag==="svg"?vr:xr}=e;if(typeof t=="string")return P.createTextNode(t);const a=n(t.tag);return Object.keys(t.attributes||[]).forEach(function(o){a.setAttribute(o,t.attributes[o])}),(t.children||[]).forEach(function(o){a.appendChild(In(o,{ceFn:n}))}),a}function Ar(t){let e=" ".concat(t.outerHTML," ");return e="".concat(e,"Font Awesome fontawesome.com "),e}const xt={replace:function(t){const e=t[0];if(e.parentNode)if(t[1].forEach(n=>{e.parentNode.insertBefore(In(n),e)}),e.getAttribute(et)===null&&p.keepOriginalSource){let n=P.createComment(Ar(e));e.parentNode.replaceChild(n,e)}else e.remove()},nest:function(t){const e=t[0],n=t[1];if(~ue(e).indexOf(p.replacementClass))return xt.replace(t);const a=new RegExp("".concat(p.cssPrefix,"-.*"));if(delete n[0].attributes.id,n[0].attributes.class){const o=n[0].attributes.class.split(" ").reduce((i,c)=>(c===p.replacementClass||c.match(a)?i.toSvg.push(c):i.toNode.push(c),i),{toNode:[],toSvg:[]});n[0].attributes.class=o.toSvg.join(" "),o.toNode.length===0?e.removeAttribute("class"):e.setAttribute("class",o.toNode.join(" "))}const r=n.map(o=>dt(o)).join(`
`);e.setAttribute(et,""),e.innerHTML=r}};function je(t){t()}function Tn(t,e){const n=typeof e=="function"?e:vt;if(t.length===0)n();else{let a=je;p.mutateApproach===ka&&(a=Q.requestAnimationFrame||je),a(()=>{const r=br(),o=ge.begin("mutate");t.map(r),o(),n()})}}let ye=!1;function Rn(){ye=!0}function ee(){ye=!1}let wt=null;function De(t){if(!Pe||!p.observeMutations)return;const{treeCallback:e=vt,nodeCallback:n=vt,pseudoElementsCallback:a=vt,observeMutationsRoot:r=P}=t;wt=new Pe(o=>{if(ye)return;const i=J();st(o).forEach(c=>{if(c.type==="childList"&&c.addedNodes.length>0&&!Fe(c.addedNodes[0])&&(p.searchPseudoElements&&a(c.target),e(c.target)),c.type==="attributes"&&c.target.parentNode&&p.searchPseudoElements&&a(c.target.parentNode),c.type==="attributes"&&Fe(c.target)&&~Ma.indexOf(c.attributeName))if(c.attributeName==="class"&&gr(c.target)){const{prefix:m,iconName:u}=Ct(ue(c.target));c.target.setAttribute(ce,m||i),u&&c.target.setAttribute(le,u)}else yr(c.target)&&n(c.target)})}),V&&wt.observe(r,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}function wr(){wt&&wt.disconnect()}function Sr(t){const e=t.getAttribute("style");let n=[];return e&&(n=e.split(";").reduce((a,r)=>{const o=r.split(":"),i=o[0],c=o.slice(1);return i&&c.length>0&&(a[i]=c.join(":").trim()),a},{})),n}function kr(t){const e=t.getAttribute("data-prefix"),n=t.getAttribute("data-icon"),a=t.innerText!==void 0?t.innerText.trim():"";let r=Ct(ue(t));return r.prefix||(r.prefix=J()),e&&n&&(r.prefix=e,r.iconName=n),r.iconName&&r.prefix||(r.prefix&&a.length>0&&(r.iconName=Xa(r.prefix,t.innerText)||pe(r.prefix,qt(t.innerText))),!r.iconName&&p.autoFetchSvg&&t.firstChild&&t.firstChild.nodeType===Node.TEXT_NODE&&(r.iconName=t.firstChild.data)),r}function Pr(t){const e=st(t.attributes).reduce((r,o)=>(r.name!=="class"&&r.name!=="style"&&(r[o.name]=o.value),r),{}),n=t.getAttribute("title"),a=t.getAttribute("data-fa-title-id");return p.autoA11y&&(n?e["aria-labelledby"]="".concat(p.replacementClass,"-title-").concat(a||ft()):(e["aria-hidden"]="true",e.focusable="false")),e}function Or(){return{iconName:null,title:null,titleId:null,prefix:null,transform:W,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function Ue(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0};const{iconName:n,prefix:a,rest:r}=kr(t),o=Pr(t),i=Kt("parseNodeAttributes",{},t);let c=e.styleParser?Sr(t):[];return l({iconName:n,title:t.getAttribute("title"),titleId:t.getAttribute("data-fa-title-id"),prefix:a,transform:W,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:r,styles:c,attributes:o}},i)}const{styles:Cr}=$;function Fn(t){const e=p.autoReplaceSvg==="nest"?Ue(t,{styleParser:!1}):Ue(t);return~e.extra.classes.indexOf(yn)?Z("generateLayersText",t,e):Z("generateSvgReplacementMutation",t,e)}function Lr(){return[...ca,...$t]}function We(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!V)return Promise.resolve();const n=P.documentElement.classList,a=d=>n.add("".concat(Le,"-").concat(d)),r=d=>n.remove("".concat(Le,"-").concat(d)),o=p.autoFetchSvg?Lr():fn.concat(Object.keys(Cr));o.includes("fa")||o.push("fa");const i=[".".concat(yn,":not([").concat(et,"])")].concat(o.map(d=>".".concat(d,":not([").concat(et,"])"))).join(", ");if(i.length===0)return Promise.resolve();let c=[];try{c=st(t.querySelectorAll(i))}catch{}if(c.length>0)a("pending"),r("complete");else return Promise.resolve();const m=ge.begin("onTree"),u=c.reduce((d,g)=>{try{const h=Fn(g);h&&d.push(h)}catch(h){hn||h.name==="MissingIcon"&&console.error(h)}return d},[]);return new Promise((d,g)=>{Promise.all(u).then(h=>{Tn(h,()=>{a("active"),a("complete"),r("pending"),typeof e=="function"&&e(),m(),d()})}).catch(h=>{m(),g(h)})})}function Er(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;Fn(t).then(n=>{n&&Tn([n],e)})}function Mr(t){return function(e){let n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const a=(e||{}).icon?e:Qt(e||{});let{mask:r}=n;return r&&(r=(r||{}).icon?r:Qt(r||{})),t(a,l(l({},n),{},{mask:r}))}}const _r=function(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{transform:n=W,symbol:a=!1,mask:r=null,maskId:o=null,title:i=null,titleId:c=null,classes:m=[],attributes:u={},styles:d={}}=e;if(!t)return;const{prefix:g,iconName:h,icon:O}=t;return Lt(l({type:"icon"},t),()=>(nt("beforeDOMElementCreation",{iconDefinition:t,params:e}),p.autoA11y&&(i?u["aria-labelledby"]="".concat(p.replacementClass,"-title-").concat(c||ft()):(u["aria-hidden"]="true",u.focusable="false")),he({icons:{main:Jt(O),mask:r?Jt(r.icon):{found:!1,width:null,height:null,icon:{}}},prefix:g,iconName:h,transform:l(l({},W),n),symbol:a,title:i,maskId:o,titleId:c,extra:{attributes:u,styles:d,classes:m}})))};var Nr={mixout(){return{icon:Mr(_r)}},hooks(){return{mutationObserverCallbacks(t){return t.treeCallback=We,t.nodeCallback=Er,t}}},provides(t){t.i2svg=function(e){const{node:n=P,callback:a=()=>{}}=e;return We(n,a)},t.generateSvgReplacementMutation=function(e,n){const{iconName:a,title:r,titleId:o,prefix:i,transform:c,symbol:m,mask:u,maskId:d,extra:g}=n;return new Promise((h,O)=>{Promise.all([Zt(a,i),u.iconName?Zt(u.iconName,u.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(z=>{let[C,x]=z;h([e,he({icons:{main:C,mask:x},prefix:i,iconName:a,transform:c,symbol:m,maskId:d,title:r,titleId:o,extra:g,watchable:!0})])}).catch(O)})},t.generateAbstractIcon=function(e){let{children:n,attributes:a,main:r,transform:o,styles:i}=e;const c=Pt(i);c.length>0&&(a.style=c);let m;return me(o)&&(m=Z("generateAbstractTransformGrouping",{main:r,transform:o,containerWidth:r.width,iconWidth:r.width})),n.push(m||r.icon),{children:n,attributes:a}}}},zr={mixout(){return{layer(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{classes:n=[]}=e;return Lt({type:"layer"},()=>{nt("beforeDOMElementCreation",{assembler:t,params:e});let a=[];return t(r=>{Array.isArray(r)?r.map(o=>{a=a.concat(o.abstract)}):a=a.concat(r.abstract)}),[{tag:"span",attributes:{class:["".concat(p.cssPrefix,"-layers"),...n].join(" ")},children:a}]})}}}},Ir={mixout(){return{counter(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{title:n=null,classes:a=[],attributes:r={},styles:o={}}=e;return Lt({type:"counter",content:t},()=>(nt("beforeDOMElementCreation",{content:t,params:e}),mr({content:t.toString(),title:n,extra:{attributes:r,styles:o,classes:["".concat(p.cssPrefix,"-layers-counter"),...a]}})))}}}},Tr={mixout(){return{text(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};const{transform:n=W,title:a=null,classes:r=[],attributes:o={},styles:i={}}=e;return Lt({type:"text",content:t},()=>(nt("beforeDOMElementCreation",{content:t,params:e}),Te({content:t,transform:l(l({},W),n),title:a,extra:{attributes:o,styles:i,classes:["".concat(p.cssPrefix,"-layers-text"),...r]}})))}}},provides(t){t.generateLayersText=function(e,n){const{title:a,transform:r,extra:o}=n;let i=null,c=null;if(cn){const m=parseInt(getComputedStyle(e).fontSize,10),u=e.getBoundingClientRect();i=u.width/m,c=u.height/m}return p.autoA11y&&!a&&(o.attributes["aria-hidden"]="true"),Promise.resolve([e,Te({content:e.innerHTML,width:i,height:c,transform:r,title:a,extra:o,watchable:!0})])}}};const Rr=new RegExp('"',"ug"),$e=[1105920,1112319],Ye=l(l(l(l({},{FontAwesome:{normal:"fas",400:"fas"}}),oa),wa),ha),ne=Object.keys(Ye).reduce((t,e)=>(t[e.toLowerCase()]=Ye[e],t),{}),Fr=Object.keys(ne).reduce((t,e)=>{const n=ne[e];return t[e]=n[900]||[...Object.entries(n)][0][1],t},{});function jr(t){const e=t.replace(Rr,""),n=Ha(e,0),a=n>=$e[0]&&n<=$e[1],r=e.length===2?e[0]===e[1]:!1;return{value:qt(r?e[0]:e),isSecondary:a||r}}function Dr(t,e){const n=t.replace(/^['"]|['"]$/g,"").toLowerCase(),a=parseInt(e),r=isNaN(a)?"normal":a;return(ne[n]||{})[r]||Fr[n]}function He(t,e){const n="".concat(Sa).concat(e.replace(":","-"));return new Promise((a,r)=>{if(t.getAttribute(n)!==null)return a();const i=st(t.children).filter(h=>h.getAttribute(Ht)===e)[0],c=Q.getComputedStyle(t,e),m=c.getPropertyValue("font-family"),u=m.match(La),d=c.getPropertyValue("font-weight"),g=c.getPropertyValue("content");if(i&&!u)return t.removeChild(i),a();if(u&&g!=="none"&&g!==""){const h=c.getPropertyValue("content");let O=Dr(m,d);const{value:z,isSecondary:C}=jr(h),x=u[0].startsWith("FontAwesome");let A=pe(O,z),S=A;if(x){const L=Ka(z);L.iconName&&L.prefix&&(A=L.iconName,O=L.prefix)}if(A&&!C&&(!i||i.getAttribute(ce)!==O||i.getAttribute(le)!==S)){t.setAttribute(n,S),i&&t.removeChild(i);const L=Or(),{extra:F}=L;F.attributes[Ht]=e,Zt(A,O).then(j=>{const q=he(l(l({},L),{},{icons:{main:j,mask:_n()},prefix:O,iconName:S,extra:F,watchable:!0})),Y=P.createElementNS("http://www.w3.org/2000/svg","svg");e==="::before"?t.insertBefore(Y,t.firstChild):t.appendChild(Y),Y.outerHTML=q.map(H=>dt(H)).join(`
`),t.removeAttribute(n),a()}).catch(r)}else a()}else a()})}function Ur(t){return Promise.all([He(t,"::before"),He(t,"::after")])}function Wr(t){return t.parentNode!==document.head&&!~Pa.indexOf(t.tagName.toUpperCase())&&!t.getAttribute(Ht)&&(!t.parentNode||t.parentNode.tagName!=="svg")}function Be(t){if(V)return new Promise((e,n)=>{const a=st(t.querySelectorAll("*")).filter(Wr).map(Ur),r=ge.begin("searchPseudoElements");Rn(),Promise.all(a).then(()=>{r(),ee(),e()}).catch(()=>{r(),ee(),n()})})}var $r={hooks(){return{mutationObserverCallbacks(t){return t.pseudoElementsCallback=Be,t}}},provides(t){t.pseudoElements2svg=function(e){const{node:n=P}=e;p.searchPseudoElements&&Be(n)}}};let Ge=!1;var Yr={mixout(){return{dom:{unwatch(){Rn(),Ge=!0}}}},hooks(){return{bootstrap(){De(Kt("mutationObserverCallbacks",{}))},noAuto(){wr()},watch(t){const{observeMutationsRoot:e}=t;Ge?ee():De(Kt("mutationObserverCallbacks",{observeMutationsRoot:e}))}}}};const Ve=t=>{let e={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return t.toLowerCase().split(" ").reduce((n,a)=>{const r=a.toLowerCase().split("-"),o=r[0];let i=r.slice(1).join("-");if(o&&i==="h")return n.flipX=!0,n;if(o&&i==="v")return n.flipY=!0,n;if(i=parseFloat(i),isNaN(i))return n;switch(o){case"grow":n.size=n.size+i;break;case"shrink":n.size=n.size-i;break;case"left":n.x=n.x-i;break;case"right":n.x=n.x+i;break;case"up":n.y=n.y-i;break;case"down":n.y=n.y+i;break;case"rotate":n.rotate=n.rotate+i;break}return n},e)};var Hr={mixout(){return{parse:{transform:t=>Ve(t)}}},hooks(){return{parseNodeAttributes(t,e){const n=e.getAttribute("data-fa-transform");return n&&(t.transform=Ve(n)),t}}},provides(t){t.generateAbstractTransformGrouping=function(e){let{main:n,transform:a,containerWidth:r,iconWidth:o}=e;const i={transform:"translate(".concat(r/2," 256)")},c="translate(".concat(a.x*32,", ").concat(a.y*32,") "),m="scale(".concat(a.size/16*(a.flipX?-1:1),", ").concat(a.size/16*(a.flipY?-1:1),") "),u="rotate(".concat(a.rotate," 0 0)"),d={transform:"".concat(c," ").concat(m," ").concat(u)},g={transform:"translate(".concat(o/2*-1," -256)")},h={outer:i,inner:d,path:g};return{tag:"g",attributes:l({},h.outer),children:[{tag:"g",attributes:l({},h.inner),children:[{tag:n.icon.tag,children:n.icon.children,attributes:l(l({},n.icon.attributes),h.path)}]}]}}}};const Rt={x:0,y:0,width:"100%",height:"100%"};function qe(t){let e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return t.attributes&&(t.attributes.fill||e)&&(t.attributes.fill="black"),t}function Br(t){return t.tag==="g"?t.children:[t]}var Gr={hooks(){return{parseNodeAttributes(t,e){const n=e.getAttribute("data-fa-mask"),a=n?Ct(n.split(" ").map(r=>r.trim())):_n();return a.prefix||(a.prefix=J()),t.mask=a,t.maskId=e.getAttribute("data-fa-mask-id"),t}}},provides(t){t.generateAbstractMask=function(e){let{children:n,attributes:a,main:r,mask:o,maskId:i,transform:c}=e;const{width:m,icon:u}=r,{width:d,icon:g}=o,h=ja({transform:c,containerWidth:d,iconWidth:m}),O={tag:"rect",attributes:l(l({},Rt),{},{fill:"white"})},z=u.children?{children:u.children.map(qe)}:{},C={tag:"g",attributes:l({},h.inner),children:[qe(l({tag:u.tag,attributes:l(l({},u.attributes),h.path)},z))]},x={tag:"g",attributes:l({},h.outer),children:[C]},A="mask-".concat(i||ft()),S="clip-".concat(i||ft()),L={tag:"mask",attributes:l(l({},Rt),{},{id:A,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"}),children:[O,x]},F={tag:"defs",children:[{tag:"clipPath",attributes:{id:S},children:Br(g)},L]};return n.push(F,{tag:"rect",attributes:l({fill:"currentColor","clip-path":"url(#".concat(S,")"),mask:"url(#".concat(A,")")},Rt)}),{children:n,attributes:a}}}},Vr={provides(t){let e=!1;Q.matchMedia&&(e=Q.matchMedia("(prefers-reduced-motion: reduce)").matches),t.missingIconAbstract=function(){const n=[],a={fill:"currentColor"},r={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};n.push({tag:"path",attributes:l(l({},a),{},{d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"})});const o=l(l({},r),{},{attributeName:"opacity"}),i={tag:"circle",attributes:l(l({},a),{},{cx:"256",cy:"364",r:"28"}),children:[]};return e||i.children.push({tag:"animate",attributes:l(l({},r),{},{attributeName:"r",values:"28;14;28;28;14;28;"})},{tag:"animate",attributes:l(l({},o),{},{values:"1;0;1;1;0;1;"})}),n.push(i),n.push({tag:"path",attributes:l(l({},a),{},{opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"}),children:e?[]:[{tag:"animate",attributes:l(l({},o),{},{values:"1;0;0;0;0;1;"})}]}),e||n.push({tag:"path",attributes:l(l({},a),{},{opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"}),children:[{tag:"animate",attributes:l(l({},o),{},{values:"0;0;1;1;0;0;"})}]}),{tag:"g",attributes:{class:"missing"},children:n}}}},qr={hooks(){return{parseNodeAttributes(t,e){const n=e.getAttribute("data-fa-symbol"),a=n===null?!1:n===""?!0:n;return t.symbol=a,t}}}},Xr=[Wa,Nr,zr,Ir,Tr,$r,Yr,Hr,Gr,Vr,qr];or(Xr,{mixoutsTo:R});R.noAuto;R.config;R.library;R.dom;const ae=R.parse;R.findIconDefinition;R.toHtml;const Kr=R.icon;R.layer;R.text;R.counter;var Ft={exports:{}},jt,Xe;function Qr(){if(Xe)return jt;Xe=1;var t="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";return jt=t,jt}var Dt,Ke;function Jr(){if(Ke)return Dt;Ke=1;var t=Qr();function e(){}function n(){}return n.resetWarningCache=e,Dt=function(){function a(i,c,m,u,d,g){if(g!==t){var h=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw h.name="Invariant Violation",h}}a.isRequired=a;function r(){return a}var o={array:a,bigint:a,bool:a,func:a,number:a,object:a,string:a,symbol:a,any:a,arrayOf:r,element:a,elementType:a,instanceOf:r,node:a,objectOf:r,oneOf:r,oneOfType:r,shape:r,exact:r,checkPropTypes:n,resetWarningCache:e};return o.PropTypes=o,o},Dt}var Qe;function Zr(){return Qe||(Qe=1,Ft.exports=Jr()()),Ft.exports}var to=Zr();const y=nn(to);var eo={};function re(t,e){(e==null||e>t.length)&&(e=t.length);for(var n=0,a=Array(e);n<e;n++)a[n]=t[n];return a}function no(t){if(Array.isArray(t))return t}function ao(t){if(Array.isArray(t))return re(t)}function K(t,e,n){return(e=uo(e))in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function ro(t){if(typeof Symbol<"u"&&t[Symbol.iterator]!=null||t["@@iterator"]!=null)return Array.from(t)}function oo(t,e){var n=t==null?null:typeof Symbol<"u"&&t[Symbol.iterator]||t["@@iterator"];if(n!=null){var a,r,o,i,c=[],m=!0,u=!1;try{if(o=(n=n.call(t)).next,e!==0)for(;!(m=(a=o.call(n)).done)&&(c.push(a.value),c.length!==e);m=!0);}catch(d){u=!0,r=d}finally{try{if(!m&&n.return!=null&&(i=n.return(),Object(i)!==i))return}finally{if(u)throw r}}return c}}function so(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function io(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Je(t,e){var n=Object.keys(t);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(t);e&&(a=a.filter(function(r){return Object.getOwnPropertyDescriptor(t,r).enumerable})),n.push.apply(n,a)}return n}function U(t){for(var e=1;e<arguments.length;e++){var n=arguments[e]!=null?arguments[e]:{};e%2?Je(Object(n),!0).forEach(function(a){K(t,a,n[a])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(n)):Je(Object(n)).forEach(function(a){Object.defineProperty(t,a,Object.getOwnPropertyDescriptor(n,a))})}return t}function co(t,e){if(t==null)return{};var n,a,r=lo(t,e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(t);for(a=0;a<o.length;a++)n=o[a],e.indexOf(n)===-1&&{}.propertyIsEnumerable.call(t,n)&&(r[n]=t[n])}return r}function lo(t,e){if(t==null)return{};var n={};for(var a in t)if({}.hasOwnProperty.call(t,a)){if(e.indexOf(a)!==-1)continue;n[a]=t[a]}return n}function Ze(t,e){return no(t)||oo(t,e)||jn(t,e)||so()}function oe(t){return ao(t)||ro(t)||jn(t)||io()}function fo(t,e){if(typeof t!="object"||!t)return t;var n=t[Symbol.toPrimitive];if(n!==void 0){var a=n.call(t,e);if(typeof a!="object")return a;throw new TypeError("@@toPrimitive must return a primitive value.")}return(e==="string"?String:Number)(t)}function uo(t){var e=fo(t,"string");return typeof e=="symbol"?e:e+""}function St(t){"@babel/helpers - typeof";return St=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(e){return typeof e}:function(e){return e&&typeof Symbol=="function"&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},St(t)}function jn(t,e){if(t){if(typeof t=="string")return re(t,e);var n={}.toString.call(t).slice(8,-1);return n==="Object"&&t.constructor&&(n=t.constructor.name),n==="Map"||n==="Set"?Array.from(t):n==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?re(t,e):void 0}}var mo="7.0.0",se;try{var po=require("@fortawesome/fontawesome-svg-core/package.json");se=po.version}catch{se=typeof process<"u"&&eo.FA_VERSION||"7.0.0"}function ho(t){var e=t.beat,n=t.fade,a=t.beatFade,r=t.bounce,o=t.shake,i=t.flash,c=t.spin,m=t.spinPulse,u=t.spinReverse,d=t.pulse,g=t.fixedWidth,h=t.inverse,O=t.border,z=t.listItem,C=t.flip,x=t.size,A=t.rotation,S=t.pull,L=t.swapOpacity,F=t.rotateBy,j=t.widthAuto,q=go(se,mo),Y=K(K(K(K(K(K({"fa-beat":e,"fa-fade":n,"fa-beat-fade":a,"fa-bounce":r,"fa-shake":o,"fa-flash":i,"fa-spin":c,"fa-spin-reverse":u,"fa-spin-pulse":m,"fa-pulse":d,"fa-fw":g,"fa-inverse":h,"fa-border":O,"fa-li":z,"fa-flip":C===!0,"fa-flip-horizontal":C==="horizontal"||C==="both","fa-flip-vertical":C==="vertical"||C==="both"},"fa-".concat(x),typeof x<"u"&&x!==null),"fa-rotate-".concat(A),typeof A<"u"&&A!==null&&A!==0),"fa-pull-".concat(S),typeof S<"u"&&S!==null),"fa-swap-opacity",L),"fa-rotate-by",q&&F),"fa-width-auto",q&&j);return Object.keys(Y).map(function(H){return Y[H]?H:null}).filter(function(H){return H})}function go(t,e){for(var n=t.split("-"),a=Ze(n,2),r=a[0],o=a[1],i=e.split("-"),c=Ze(i,2),m=c[0],u=c[1],d=r.split("."),g=m.split("."),h=0;h<Math.max(d.length,g.length);h++){var O=d[h]||"0",z=g[h]||"0",C=parseInt(O,10),x=parseInt(z,10);if(C!==x)return C>x}for(var A=0;A<Math.max(d.length,g.length);A++){var S=d[A]||"0",L=g[A]||"0";if(S!==L&&S.length!==L.length)return S.length<L.length}return!(o&&!u)}function yo(t){return t=t-0,t===t}function Dn(t){return yo(t)?t:(t=t.replace(/[\-_\s]+(.)?/g,function(e,n){return n?n.toUpperCase():""}),t.substr(0,1).toLowerCase()+t.substr(1))}var bo=["style"];function vo(t){return t.charAt(0).toUpperCase()+t.slice(1)}function xo(t){return t.split(";").map(function(e){return e.trim()}).filter(function(e){return e}).reduce(function(e,n){var a=n.indexOf(":"),r=Dn(n.slice(0,a)),o=n.slice(a+1).trim();return r.startsWith("webkit")?e[vo(r)]=o:e[r]=o,e},{})}function Un(t,e){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof e=="string")return e;var a=(e.children||[]).map(function(m){return Un(t,m)}),r=Object.keys(e.attributes||{}).reduce(function(m,u){var d=e.attributes[u];switch(u){case"class":m.attrs.className=d,delete e.attributes.class;break;case"style":m.attrs.style=xo(d);break;default:u.indexOf("aria-")===0||u.indexOf("data-")===0?m.attrs[u.toLowerCase()]=d:m.attrs[Dn(u)]=d}return m},{attrs:{}}),o=n.style,i=o===void 0?{}:o,c=co(n,bo);return r.attrs.style=U(U({},r.attrs.style),i),t.apply(void 0,[e.tag,U(U({},r.attrs),c)].concat(oe(a)))}var Wn=!1;try{Wn=!0}catch{}function Ao(){if(!Wn&&console&&typeof console.error=="function"){var t;(t=console).error.apply(t,arguments)}}function tn(t){if(t&&St(t)==="object"&&t.prefix&&t.iconName&&t.icon)return t;if(ae.icon)return ae.icon(t);if(t===null)return null;if(t&&St(t)==="object"&&t.prefix&&t.iconName)return t;if(Array.isArray(t)&&t.length===2)return{prefix:t[0],iconName:t[1]};if(typeof t=="string")return{prefix:"fas",iconName:t}}function Ut(t,e){return Array.isArray(e)&&e.length>0||!Array.isArray(e)&&e?K({},t,e):{}}var en={border:!1,className:"",mask:null,maskId:null,fixedWidth:!1,inverse:!1,flip:!1,icon:null,listItem:!1,pull:null,pulse:!1,rotation:null,rotateBy:!1,size:null,spin:!1,spinPulse:!1,spinReverse:!1,beat:!1,fade:!1,beatFade:!1,bounce:!1,shake:!1,symbol:!1,title:"",titleId:null,transform:null,swapOpacity:!1,widthAuto:!1},$n=an.forwardRef(function(t,e){var n=U(U({},en),t),a=n.icon,r=n.mask,o=n.symbol,i=n.className,c=n.title,m=n.titleId,u=n.maskId,d=tn(a),g=Ut("classes",[].concat(oe(ho(n)),oe((i||"").split(" ")))),h=Ut("transform",typeof n.transform=="string"?ae.transform(n.transform):n.transform),O=Ut("mask",tn(r)),z=Kr(d,U(U(U(U({},g),h),O),{},{symbol:o,title:c,titleId:m,maskId:u}));if(!z)return Ao("Could not find icon",d),null;var C=z.abstract,x={ref:e};return Object.keys(n).forEach(function(A){en.hasOwnProperty(A)||(x[A]=n[A])}),wo(C[0],x)});$n.displayName="FontAwesomeIcon";$n.propTypes={beat:y.bool,border:y.bool,beatFade:y.bool,bounce:y.bool,className:y.string,fade:y.bool,flash:y.bool,mask:y.oneOfType([y.object,y.array,y.string]),maskId:y.string,fixedWidth:y.bool,inverse:y.bool,flip:y.oneOf([!0,!1,"horizontal","vertical","both"]),icon:y.oneOfType([y.object,y.array,y.string]),listItem:y.bool,pull:y.oneOf(["right","left"]),pulse:y.bool,rotation:y.oneOf([0,90,180,270]),rotateBy:y.bool,shake:y.bool,size:y.oneOf(["2xs","xs","sm","lg","xl","2xl","1x","2x","3x","4x","5x","6x","7x","8x","9x","10x"]),spin:y.bool,spinPulse:y.bool,spinReverse:y.bool,symbol:y.oneOfType([y.bool,y.string]),title:y.string,titleId:y.string,transform:y.oneOfType([y.string,y.object]),swapOpacity:y.bool,widthAuto:y.bool};var wo=Un.bind(null,an.createElement);const Co={prefix:"fas",iconName:"person",icon:[320,512,[129485,"male"],"f183","M112 48a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm40 304l0 128c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-223.1L59.4 304.5c-9.1 15.1-28.8 20-43.9 10.9s-20-28.8-10.9-43.9l58.3-97c17.4-28.9 48.6-46.6 82.3-46.6l29.7 0c33.7 0 64.9 17.7 82.3 46.6l58.3 97c9.1 15.1 4.2 34.8-10.9 43.9s-34.8 4.2-43.9-10.9L232 256.9 232 480c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-128-16 0z"]},Lo={prefix:"fas",iconName:"address-book",icon:[512,512,[62138,"contact-book"],"f2b9","M96 0C60.7 0 32 28.7 32 64l0 384c0 35.3 28.7 64 64 64l288 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L96 0zM208 288l64 0c44.2 0 80 35.8 80 80c0 8.8-7.2 16-16 16l-192 0c-8.8 0-16-7.2-16-16c0-44.2 35.8-80 80-80zm-32-96a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zM512 80c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64zM496 192c-8.8 0-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64c0-8.8-7.2-16-16-16zm16 144c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64z"]},Eo={prefix:"fas",iconName:"pencil",icon:[512,512,[9999,61504,"pencil-alt"],"f303","M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1 0 32c0 8.8 7.2 16 16 16l32 0zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z"]},Mo={prefix:"fas",iconName:"table",icon:[512,512,[],"f0ce","M64 256l0-96 160 0 0 96L64 256zm0 64l160 0 0 96L64 416l0-96zm224 96l0-96 160 0 0 96-160 0zM448 256l-160 0 0-96 160 0 0 96zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z"]},_o={prefix:"fas",iconName:"road-spikes",icon:[640,512,[],"e568","M64 116.8c0-15.8 20.5-22 29.3-8.9L192 256l0-139.2c0-15.8 20.5-22 29.3-8.9L320 256l0-139.2c0-15.8 20.5-22 29.3-8.9L448 256l0-139.2c0-15.8 20.5-22 29.3-8.9L606.8 302.2c14.2 21.3-1.1 49.7-26.6 49.7L512 352l-64 0-64 0-64 0-64 0-64 0L64 352l0-235.2zM32 384l576 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 448c-17.7 0-32-14.3-32-32s14.3-32 32-32z"]},No={prefix:"fas",iconName:"gamepad",icon:[640,512,[],"f11b","M192 64C86 64 0 150 0 256S86 448 192 448l256 0c106 0 192-86 192-192s-86-192-192-192L192 64zM496 168a40 40 0 1 1 0 80 40 40 0 1 1 0-80zM392 304a40 40 0 1 1 80 0 40 40 0 1 1 -80 0zM168 200c0-13.3 10.7-24 24-24s24 10.7 24 24l0 32 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-32 0 0 32c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-32-32 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-32z"]},So={prefix:"fas",iconName:"circle-dot",icon:[512,512,[128280,"dot-circle"],"f192","M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm0-352a96 96 0 1 1 0 192 96 96 0 1 1 0-192z"]},zo=So,Io={prefix:"fas",iconName:"lock",icon:[448,512,[128274],"f023","M144 144l0 48 160 0 0-48c0-44.2-35.8-80-80-80s-80 35.8-80 80zM80 192l0-48C80 64.5 144.5 0 224 0s144 64.5 144 144l0 48 16 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 256c0-35.3 28.7-64 64-64l16 0z"]},To={prefix:"fas",iconName:"i-cursor",icon:[256,512,[],"f246","M.1 29.3C-1.4 47 11.7 62.4 29.3 63.9l8 .7C70.5 67.3 96 95 96 128.3L96 224l-32 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l32 0 0 95.7c0 33.3-25.5 61-58.7 63.8l-8 .7C11.7 449.6-1.4 465 .1 482.7s16.9 30.7 34.5 29.2l8-.7c34.1-2.8 64.2-18.9 85.4-42.9c21.2 24 51.2 40 85.4 42.9l8 .7c17.6 1.5 33.1-11.6 34.5-29.2s-11.6-33.1-29.2-34.5l-8-.7C185.5 444.7 160 417 160 383.7l0-95.7 32 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-32 0 0-95.7c0-33.3 25.5-61 58.7-63.8l8-.7c17.6-1.5 30.7-16.9 29.2-34.5S239-1.4 221.3 .1l-8 .7C179.2 3.6 149.2 19.7 128 43.7c-21.2-24-51.2-40-85.4-42.9l-8-.7C17-1.4 1.6 11.7 .1 29.3z"]},Ro={prefix:"fas",iconName:"ban",icon:[512,512,[128683,"cancel"],"f05e","M367.2 412.5L99.5 144.8C77.1 176.1 64 214.5 64 256c0 106 86 192 192 192c41.5 0 79.9-13.1 111.2-35.5zm45.3-45.3C434.9 335.9 448 297.5 448 256c0-106-86-192-192-192c-41.5 0-79.9 13.1-111.2 35.5L412.5 367.2zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256z"]},Fo={prefix:"fas",iconName:"box",icon:[448,512,[128230],"f466","M50.7 58.5L0 160l208 0 0-128L93.7 32C75.5 32 58.9 42.3 50.7 58.5zM240 160l208 0L397.3 58.5C389.1 42.3 372.5 32 354.3 32L240 32l0 128zm208 32L0 192 0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-224z"]},jo={prefix:"fas",iconName:"person-running",icon:[448,512,[127939,"running"],"f70c","M320 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM125.7 175.5c9.9-9.9 23.4-15.5 37.5-15.5c1.9 0 3.8 .1 5.6 .3L137.6 254c-9.3 28 1.7 58.8 26.8 74.5l86.2 53.9-25.4 88.8c-4.9 17 5 34.7 22 39.6s34.7-5 39.6-22l28.7-100.4c5.9-20.6-2.6-42.6-20.7-53.9L238 299l30.9-82.4 5.1 12.3C289 264.7 323.9 288 362.7 288l21.3 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-21.3 0c-12.9 0-24.6-7.8-29.5-19.7l-6.3-15c-14.6-35.1-44.1-61.9-80.5-73.1l-48.7-15c-11.1-3.4-22.7-5.2-34.4-5.2c-31 0-60.8 12.3-82.7 34.3L57.4 153.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l23.1-23.1zM91.2 352L32 352c-17.7 0-32 14.3-32 32s14.3 32 32 32l69.6 0c19 0 36.2-11.2 43.9-28.5L157 361.6l-9.5-6c-17.5-10.9-30.5-26.8-37.9-44.9L91.2 352z"]},Do={prefix:"fas",iconName:"arrows-turn-right",icon:[448,512,[],"e4c0","M297.4 9.4c12.5-12.5 32.8-12.5 45.3 0l96 96c12.5 12.5 12.5 32.8 0 45.3l-96 96c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L338.7 160 128 160c-35.3 0-64 28.7-64 64l0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32C0 153.3 57.3 96 128 96l210.7 0L297.4 54.6c-12.5-12.5-12.5-32.8 0-45.3zm-96 256c12.5-12.5 32.8-12.5 45.3 0l96 96c12.5 12.5 12.5 32.8 0 45.3l-96 96c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 416 96 416c-17.7 0-32 14.3-32 32l0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32c0-53 43-96 96-96l146.7 0-41.4-41.4c-12.5-12.5-12.5-32.8 0-45.3z"]},Uo={prefix:"fas",iconName:"arrows-left-right",icon:[512,512,["arrows-h"],"f07e","M406.6 374.6l96-96c12.5-12.5 12.5-32.8 0-45.3l-96-96c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L402.7 224l-293.5 0 41.4-41.4c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-96 96c-12.5 12.5-12.5 32.8 0 45.3l96 96c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.3 288l293.5 0-41.4 41.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0z"]},Wo={prefix:"fas",iconName:"arrows-rotate",icon:[512,512,[128472,"refresh","sync"],"f021","M105.1 202.6c7.7-21.8 20.2-42.3 37.8-59.8c62.5-62.5 163.8-62.5 226.3 0L386.3 160 352 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l111.5 0c0 0 0 0 0 0l.4 0c17.7 0 32-14.3 32-32l0-112c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 35.2L414.4 97.6c-87.5-87.5-229.3-87.5-316.8 0C73.2 122 55.6 150.7 44.8 181.4c-5.9 16.7 2.9 34.9 19.5 40.8s34.9-2.9 40.8-19.5zM39 289.3c-5 1.5-9.8 4.2-13.7 8.2c-4 4-6.7 8.8-8.1 14c-.3 1.2-.6 2.5-.8 3.8c-.3 1.7-.4 3.4-.4 5.1L16 432c0 17.7 14.3 32 32 32s32-14.3 32-32l0-35.1 17.6 17.5c0 0 0 0 0 0c87.5 87.4 229.3 87.4 316.7 0c24.4-24.4 42.1-53.1 52.9-83.8c5.9-16.7-2.9-34.9-19.5-40.8s-34.9 2.9-40.8 19.5c-7.7 21.8-20.2 42.3-37.8 59.8c-62.5 62.5-163.8 62.5-226.3 0l-.1-.1L125.6 352l34.4 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L48.4 288c-1.6 0-3.2 .1-4.8 .3s-3.1 .5-4.6 1z"]},$o={prefix:"fas",iconName:"square",icon:[448,512,[9632,9723,9724,61590],"f0c8","M0 96C0 60.7 28.7 32 64 32H384c35.3 0 64 28.7 64 64V416c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V96z"]},Yo={prefix:"fas",iconName:"arrow-right",icon:[448,512,[8594],"f061","M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"]},Ho={prefix:"fas",iconName:"heart",icon:[512,512,[128153,128154,128155,128156,128420,129293,129294,129505,9829,10084,61578],"f004","M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"]},Bo={prefix:"fas",iconName:"circle",icon:[512,512,[128308,128309,128992,128993,128994,128995,128996,9679,9898,9899,11044,61708,61915],"f111","M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z"]},Go={prefix:"fas",iconName:"file-image",icon:[384,512,[128443],"f1c5","M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-288-128 0c-17.7 0-32-14.3-32-32L224 0 64 0zM256 0l0 128 128 0L256 0zM64 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm152 32c5.3 0 10.2 2.6 13.2 6.9l88 128c3.4 4.9 3.7 11.3 1 16.5s-8.2 8.6-14.2 8.6l-88 0-40 0-48 0-48 0c-5.8 0-11.1-3.1-13.9-8.1s-2.8-11.2 .2-16.1l48-80c2.9-4.8 8.1-7.8 13.7-7.8s10.8 2.9 13.7 7.8l12.8 21.4 48.3-70.2c3-4.3 7.9-6.9 13.2-6.9z"]},ko={prefix:"fas",iconName:"circle-question",icon:[512,512,[62108,"question-circle"],"f059","M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM169.8 165.3c7.9-22.3 29.1-37.3 52.8-37.3l58.3 0c34.9 0 63.1 28.3 63.1 63.1c0 22.6-12.1 43.5-31.7 54.8L280 264.4c-.2 13-10.9 23.6-24 23.6c-13.3 0-24-10.7-24-24l0-13.5c0-8.6 4.6-16.5 12.1-20.8l44.3-25.4c4.7-2.7 7.6-7.7 7.6-13.1c0-8.4-6.8-15.1-15.1-15.1l-58.3 0c-3.4 0-6.4 2.1-7.5 5.3l-.4 1.2c-4.4 12.5-18.2 19-30.6 14.6s-19-18.2-14.6-30.6l.4-1.2zM224 352a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"]},Vo=ko,qo={prefix:"fas",iconName:"bars-progress",icon:[512,512,["tasks-alt"],"f828","M448 160l-128 0 0-32 128 0 0 32zM48 64C21.5 64 0 85.5 0 112l0 64c0 26.5 21.5 48 48 48l416 0c26.5 0 48-21.5 48-48l0-64c0-26.5-21.5-48-48-48L48 64zM448 352l0 32-256 0 0-32 256 0zM48 288c-26.5 0-48 21.5-48 48l0 64c0 26.5 21.5 48 48 48l416 0c26.5 0 48-21.5 48-48l0-64c0-26.5-21.5-48-48-48L48 288z"]},Xo={prefix:"fas",iconName:"eye",icon:[576,512,[128065],"f06e","M288 32c-80.8 0-145.5 36.8-192.6 80.6C48.6 156 17.3 208 2.5 243.7c-3.3 7.9-3.3 16.7 0 24.6C17.3 304 48.6 356 95.4 399.4C142.5 443.2 207.2 480 288 480s145.5-36.8 192.6-80.6c46.8-43.5 78.1-95.4 93-131.1c3.3-7.9 3.3-16.7 0-24.6c-14.9-35.7-46.2-87.7-93-131.1C433.5 68.8 368.8 32 288 32zM144 256a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm144-64c0 35.3-28.7 64-64 64c-7.1 0-13.9-1.2-20.3-3.3c-5.5-1.8-11.9 1.6-11.7 7.4c.3 6.9 1.3 13.8 3.2 20.7c13.7 51.2 66.4 81.6 117.6 67.9s81.6-66.4 67.9-117.6c-11.1-41.5-47.8-69.4-88.6-71.1c-5.8-.2-9.2 6.1-7.4 11.7c2.1 6.4 3.3 13.2 3.3 20.3z"]},Po={prefix:"fas",iconName:"floppy-disk",icon:[448,512,[128190,128426,"save"],"f0c7","M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-242.7c0-17-6.7-33.3-18.7-45.3L352 50.7C340 38.7 323.7 32 306.7 32L64 32zm0 96c0-17.7 14.3-32 32-32l192 0c17.7 0 32 14.3 32 32l0 64c0 17.7-14.3 32-32 32L96 224c-17.7 0-32-14.3-32-32l0-64zM224 288a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"]},Ko=Po,Qo={prefix:"fas",iconName:"hand-pointer",icon:[448,512,[],"f25a","M128 40c0-22.1 17.9-40 40-40s40 17.9 40 40l0 148.2c8.5-7.6 19.7-12.2 32-12.2c20.6 0 38.2 13 45 31.2c8.8-9.3 21.2-15.2 35-15.2c25.3 0 46 19.5 47.9 44.3c8.5-7.7 19.8-12.3 32.1-12.3c26.5 0 48 21.5 48 48l0 48 0 16 0 48c0 70.7-57.3 128-128 128l-16 0-64 0-.1 0-5.2 0c-5 0-9.9-.3-14.7-1c-55.3-5.6-106.2-34-140-79L8 336c-13.3-17.7-9.7-42.7 8-56s42.7-9.7 56 8l56 74.7L128 40zM240 304c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96zm48-16c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96c0-8.8-7.2-16-16-16zm80 16c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96z"]},Jo={prefix:"fas",iconName:"arrow-left",icon:[448,512,[8592],"f060","M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"]},Zo={prefix:"fas",iconName:"gear",icon:[512,512,[9881,"cog"],"f013","M495.9 166.6c3.2 8.7 .5 18.4-6.4 24.6l-43.3 39.4c1.1 8.3 1.7 16.8 1.7 25.4s-.6 17.1-1.7 25.4l43.3 39.4c6.9 6.2 9.6 15.9 6.4 24.6c-4.4 11.9-9.7 23.3-15.8 34.3l-4.7 8.1c-6.6 11-14 21.4-22.1 31.2c-5.9 7.2-15.7 9.6-24.5 6.8l-55.7-17.7c-13.4 10.3-28.2 18.9-44 25.4l-12.5 57.1c-2 9.1-9 16.3-18.2 17.8c-13.8 2.3-28 3.5-42.5 3.5s-28.7-1.2-42.5-3.5c-9.2-1.5-16.2-8.7-18.2-17.8l-12.5-57.1c-15.8-6.5-30.6-15.1-44-25.4L83.1 425.9c-8.8 2.8-18.6 .3-24.5-6.8c-8.1-9.8-15.5-20.2-22.1-31.2l-4.7-8.1c-6.1-11-11.4-22.4-15.8-34.3c-3.2-8.7-.5-18.4 6.4-24.6l43.3-39.4C64.6 273.1 64 264.6 64 256s.6-17.1 1.7-25.4L22.4 191.2c-6.9-6.2-9.6-15.9-6.4-24.6c4.4-11.9 9.7-23.3 15.8-34.3l4.7-8.1c6.6-11 14-21.4 22.1-31.2c5.9-7.2 15.7-9.6 24.5-6.8l55.7 17.7c13.4-10.3 28.2-18.9 44-25.4l12.5-57.1c2-9.1 9-16.3 18.2-17.8C227.3 1.2 241.5 0 256 0s28.7 1.2 42.5 3.5c9.2 1.5 16.2 8.7 18.2 17.8l12.5 57.1c15.8 6.5 30.6 15.1 44 25.4l55.7-17.7c8.8-2.8 18.6-.3 24.5 6.8c8.1 9.8 15.5 20.2 22.1 31.2l4.7 8.1c6.1 11 11.4 22.4 15.8 34.3zM256 336a80 80 0 1 0 0-160 80 80 0 1 0 0 160z"]},ts={prefix:"fas",iconName:"keyboard",icon:[576,512,[9e3],"f11c","M64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zm16 64l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zM64 240c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm16 80l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zm80-176c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm16 80l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zM160 336c0-8.8 7.2-16 16-16l224 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-224 0c-8.8 0-16-7.2-16-16l0-32zM272 128l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zM256 240c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zM368 128l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zM352 240c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zM464 128l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zM448 240c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm16 80l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16z"]},es={prefix:"fas",iconName:"rotate-right",icon:[512,512,["redo-alt","rotate-forward"],"f2f9","M463.5 224l8.5 0c13.3 0 24-10.7 24-24l0-128c0-9.7-5.8-18.5-14.8-22.2s-19.3-1.7-26.2 5.2L413.4 96.6c-87.6-86.5-228.7-86.2-315.8 1c-87.5 87.5-87.5 229.3 0 316.8s229.3 87.5 316.8 0c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0c-62.5 62.5-163.8 62.5-226.3 0s-62.5-163.8 0-226.3c62.2-62.2 162.7-62.5 225.3-1L327 183c-6.9 6.9-8.9 17.2-5.2 26.2s12.5 14.8 22.2 14.8l119.5 0z"]},ns={prefix:"fas",iconName:"bolt",icon:[448,512,[9889,"zap"],"f0e7","M349.4 44.6c5.9-13.7 1.5-29.7-10.6-38.5s-28.6-8-39.9 1.8l-256 224c-10 8.8-13.6 22.9-8.9 35.3S50.7 288 64 288l111.5 0L98.6 467.4c-5.9 13.7-1.5 29.7 10.6 38.5s28.6 8 39.9-1.8l256-224c10-8.8 13.6-22.9 8.9-35.3s-16.6-20.7-30-20.7l-111.5 0L349.4 44.6z"]},as={prefix:"fas",iconName:"ellipsis",icon:[448,512,["ellipsis-h"],"f141","M8 256a56 56 0 1 1 112 0A56 56 0 1 1 8 256zm160 0a56 56 0 1 1 112 0 56 56 0 1 1 -112 0zm216-56a56 56 0 1 1 0 112 56 56 0 1 1 0-112z"]},rs={prefix:"fas",iconName:"bug",icon:[512,512,[],"f188","M256 0c53 0 96 43 96 96l0 3.6c0 15.7-12.7 28.4-28.4 28.4l-135.1 0c-15.7 0-28.4-12.7-28.4-28.4l0-3.6c0-53 43-96 96-96zM41.4 105.4c12.5-12.5 32.8-12.5 45.3 0l64 64c.7 .7 1.3 1.4 1.9 2.1c14.2-7.3 30.4-11.4 47.5-11.4l112 0c17.1 0 33.2 4.1 47.5 11.4c.6-.7 1.2-1.4 1.9-2.1l64-64c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-64 64c-.7 .7-1.4 1.3-2.1 1.9c6.2 12 10.1 25.3 11.1 39.5l64.3 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c0 24.6-5.5 47.8-15.4 68.6c2.2 1.3 4.2 2.9 6 4.8l64 64c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-63.1-63.1c-24.5 21.8-55.8 36.2-90.3 39.6L272 240c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 239.2c-34.5-3.4-65.8-17.8-90.3-39.6L86.6 502.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l64-64c1.9-1.9 3.9-3.4 6-4.8C101.5 367.8 96 344.6 96 320l-64 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64.3 0c1.1-14.1 5-27.5 11.1-39.5c-.7-.6-1.4-1.2-2.1-1.9l-64-64c-12.5-12.5-12.5-32.8 0-45.3z"]},os={prefix:"fas",iconName:"arrows-left-right-to-line",icon:[640,512,[],"e4ba","M32 64c17.7 0 32 14.3 32 32l0 320c0 17.7-14.3 32-32 32s-32-14.3-32-32L0 96C0 78.3 14.3 64 32 64zm214.6 73.4c12.5 12.5 12.5 32.8 0 45.3L205.3 224l229.5 0-41.4-41.4c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l96 96c12.5 12.5 12.5 32.8 0 45.3l-96 96c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L434.7 288l-229.5 0 41.4 41.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-96-96c-12.5-12.5-12.5-32.8 0-45.3l96-96c12.5-12.5 32.8-12.5 45.3 0zM640 96l0 320c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-320c0-17.7 14.3-32 32-32s32 14.3 32 32z"]},ss={prefix:"fas",iconName:"play",icon:[384,512,[9654],"f04b","M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"]},is={prefix:"fas",iconName:"magnifying-glass",icon:[512,512,[128269,"search"],"f002","M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"]},cs={prefix:"fas",iconName:"copy",icon:[448,512,[],"f0c5","M208 0L332.1 0c12.7 0 24.9 5.1 33.9 14.1l67.9 67.9c9 9 14.1 21.2 14.1 33.9L448 336c0 26.5-21.5 48-48 48l-192 0c-26.5 0-48-21.5-48-48l0-288c0-26.5 21.5-48 48-48zM48 128l80 0 0 64-64 0 0 256 192 0 0-32 64 0 0 48c0 26.5-21.5 48-48 48L48 512c-26.5 0-48-21.5-48-48L0 176c0-26.5 21.5-48 48-48z"]},ls={prefix:"fas",iconName:"chevron-left",icon:[320,512,[9001],"f053","M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"]},fs={prefix:"fas",iconName:"chevron-right",icon:[320,512,[9002],"f054","M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"]},us={prefix:"fas",iconName:"hashtag",icon:[448,512,[62098],"23","M181.3 32.4c17.4 2.9 29.2 19.4 26.3 36.8L197.8 128l95.1 0 11.5-69.3c2.9-17.4 19.4-29.2 36.8-26.3s29.2 19.4 26.3 36.8L357.8 128l58.2 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-68.9 0L325.8 320l58.2 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-68.9 0-11.5 69.3c-2.9 17.4-19.4 29.2-36.8 26.3s-29.2-19.4-26.3-36.8l9.8-58.7-95.1 0-11.5 69.3c-2.9 17.4-19.4 29.2-36.8 26.3s-29.2-19.4-26.3-36.8L90.2 384 32 384c-17.7 0-32-14.3-32-32s14.3-32 32-32l68.9 0 21.3-128L64 192c-17.7 0-32-14.3-32-32s14.3-32 32-32l68.9 0 11.5-69.3c2.9-17.4 19.4-29.2 36.8-26.3zM187.1 192L165.8 320l95.1 0 21.3-128-95.1 0z"]},ms={prefix:"fas",iconName:"circle-plus",icon:[512,512,["plus-circle"],"f055","M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM232 344l0-64-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64 0 0-64c0-13.3 10.7-24 24-24s24 10.7 24 24l0 64 64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0 0 64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"]},ds={prefix:"fas",iconName:"check",icon:[448,512,[10003,10004],"f00c","M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z"]};export{To as A,Lo as B,is as C,ms as D,Eo as E,$n as F,Fo as G,Zo as H,Vo as I,fs as J,Oo as K,ds as L,cs as M,Wo as N,Ko as O,$o as P,Bo as Q,an as R,zo as S,Yo as T,Jo as U,Xn as a,rs as b,Ho as c,Co as d,Io as e,ls as f,nn as g,No as h,ns as i,_o as j,ts as k,Uo as l,os as m,us as n,Mo as o,es as p,Xo as q,qn as r,as as s,ss as t,qo as u,Go as v,Ro as w,Do as x,Qo as y,jo as z};
